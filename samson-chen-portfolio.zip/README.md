# Samson Chen — Design & Research Portfolio

A responsive, English-language portfolio with an introduction, a horizontal three-stage design journey, and an expandable master's research framework. Built with HTML, CSS, and JavaScript. No build step or package installation is required.

## Preview

Open `dist/index.html` in a browser, or serve the `dist` folder using any static web server. Google Fonts are optional; system fonts work offline.

## Publish on GitHub Pages

1. Upload this repository to your GitHub account, retaining the `.github/workflows/pages.yml` file.
2. In repository Settings → Pages, choose **GitHub Actions** as the source.
3. Push to `main`, or run **Publish portfolio to GitHub Pages** in the Actions tab.
4. After deployment succeeds, the Pages environment displays the live website URL.

## Add your photographs later

No actual portfolio photos or portrait are included. The initial layout intentionally uses labeled typographic placeholders; no example artwork is presented as Samson's work.

1. Upload JPG, PNG, or WebP files into `dist/images/`.
2. Open `dist/script.js` and edit the four paths in `portfolioImages`:

```js
const portfolioImages = {
  portrait: 'images/portrait.jpg',
  beginning: 'images/original-character.jpg',
  brand: 'images/chen-universe.jpg',
  ai: 'images/ai-process.jpg'
};
```

3. Update `imageDescriptions` with accurate descriptions for accessibility.
4. Commit your changes. GitHub Actions republishes the site.

Keep a value empty to retain its designed placeholder. Portrait: approximately 4:5. Work images: approximately 3:2. Aim for 1600–2000 pixels on the longest side and under 500 KB where possible. Images are cropped to fit; adjust `object-position` in `style.css` when needed.

## Edit content

- `dist/index.html`: all English biography, project descriptions, and research text.
- `dist/style.css`: typography, colors, responsive layout, and photo cropping.
- `dist/script.js`: photo paths, timeline arrows, keyboard controls, and active navigation.

The research is explicitly preliminary. Replace it with verified methods and findings when ready. Software tools currently use consistent text monograms rather than official brand artwork.

## 中文換圖說明

把照片上傳到 `dist/images/`，再到 `dist/script.js` 修改 `portfolioImages` 的四個圖片路徑即可。檔名大小寫必須相同。空白路徑會保留原本的排版，不會出現破圖。研究文字可直接在 `dist/index.html` 編輯。推送到 main 後會觸發 GitHub Pages 更新。
